package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_list_view_one.*

class ListView_one : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view_one)

        var foodArray = resources.getStringArray(R.array.FoodName)

        var arrayAdapter = ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, foodArray)

        listView_1.adapter = arrayAdapter
        listView_1.setOnItemClickListener { parent, view, position, id ->
            Toast.makeText(this, foodArray[position], Toast.LENGTH_SHORT).show()

        }
    }
}