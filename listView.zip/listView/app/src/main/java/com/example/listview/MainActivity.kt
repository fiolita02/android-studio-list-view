package com.example.listview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            btn_view1.setOnClickListener{
                val intent = Intent(this, ListView_one:: class.java)
                startActivity(intent)
            }
            btn_view2.setOnClickListener{
                val intent = Intent(this, ListView_two:: class.java)
                startActivity(intent)
        }
            btn_view3.setOnClickListener{
                val intent = Intent(this, ListView_three:: class.java)
                startActivity(intent)
        }
            btn_view4.setOnClickListener{
                val intent = Intent(this, ListView_four:: class.java)
                startActivity(intent)
        }
        }
    }
