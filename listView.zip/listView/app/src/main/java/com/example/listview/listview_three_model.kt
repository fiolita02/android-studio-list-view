package com.example.listview

class listview_three_model {

    var name: String? = null
    var images source: int = 0

    fun getNames(): String {
        return name.toString()
    }

    fun setName(): String {
        this.name = name
    }

    fun getImage(): Int {
        return images_source
    }

    fun setImage(image_source: Int) {
        this.image_source = image_source
    }
}


