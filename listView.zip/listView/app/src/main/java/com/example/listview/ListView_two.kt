package com.example.listview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class ListView_two : AppCompatActivity() {

    var array = arrayOf("sate padang", "nasi goreng", "mie goreng", "mie ayam", "Ikan Bakar", "Nasi Bakar", "kwetiaw", "Bakso")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view_two)

        val adapter = ArrayAdapter(this, R.layout.list_view_model, array)
        val listView: ListView= findViewById(R.id.listView_2)
        listView.setAdapter(adapter)

        listView.onItemClickListener= object : AdapterView.OnItemClickListener{
            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val itemValue = listView.getItemAtPosition(position)as String
                Toast.makeText(applicationContext, "Value: $itemValue", Toast.LENGTH_SHORT).show()
            }
        }

    }
}